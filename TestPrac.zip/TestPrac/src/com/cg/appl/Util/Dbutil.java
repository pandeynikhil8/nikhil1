package com.cg.appl.Util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.appl.exception.UserException;

public class Dbutil {
	public static Connection obtainConnection() throws UserException, NamingException{
		Connection conn=null;
		InitialContext context;
		 
		try {
			context = new InitialContext();
			DataSource source=(DataSource) context .lookup("java:/OracleDS");
			conn=source.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UserException("username doesnot exist");
			
		}
		
		return conn;
	}	
	
	
}
