package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.appl.Util.Dbutil;
import com.cg.appl.entities.User1;
import com.cg.appl.exception.UserException;

import com.cg.appl.Util.*;


public class UserDaoImpl implements UserDao{
private Dbutil util;
private Connection con=null;
	
	public UserDaoImpl() {
	try {
		con=Dbutil.obtainConnection();
	} catch (UserException | NamingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}


	@Override
	public boolean addUser(User1 usr) throws UserException {
		String qry="insert into User123 values(?,?,?,?)";
		System.out.println(con);
		PreparedStatement pst;
		ResultSet rs;
		try {
			pst=con.prepareStatement(qry);
			pst.setString(1, usr.getName());
			pst.setString(2, usr.getUsername());
			pst.setString(3, usr.getPassword());
			pst.setString(4, usr.getMobno());
			rs=pst.executeQuery();
			if(rs!=null)
			{
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
		
	}

}
