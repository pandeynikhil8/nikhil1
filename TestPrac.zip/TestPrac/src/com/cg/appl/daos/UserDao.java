package com.cg.appl.daos;

import com.cg.appl.entities.User1;
import com.cg.appl.exception.UserException;

public interface UserDao {
	public boolean addUser(User1 usr) throws UserException;
}
