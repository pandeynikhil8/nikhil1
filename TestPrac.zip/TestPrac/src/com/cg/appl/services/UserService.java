package com.cg.appl.services;

import com.cg.appl.entities.User1;
import com.cg.appl.exception.UserException;

public interface UserService {
	public boolean addUser(User1 usr) throws UserException;
}
