package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.appl.entities.User1;
import com.cg.appl.exception.UserException;
import com.cg.appl.services.UserService;
import com.cg.appl.services.UserServiceImpl;


@WebServlet("*.do")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService service;
   private String nextJsp;
  
   
	public UserController() {
	service=new UserServiceImpl();
	}
	
	

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String command=request.getServletPath();
      int avlAmount=700;
		System.out.println(command);
		switch (command) {
		case "/index.do":{
			nextJsp="/showForm.jsp";
			 System.out.println(nextJsp);
		}
			break;
			
		case "/reg.do":{
		
			 String name	=	request.getParameter("name");
				
			 String username	=	request.getParameter("username");
				
			 String password	=	request.getParameter("password");
				
			 String mobno	=	request.getParameter("mobno");
			 User1 user=new User1(name, username, password, mobno);
			try {
				boolean success=service.addUser(user);
				if(success)
				{ HttpSession session=request.getSession(true);
				 session.setAttribute("name", name);
				 session.setAttribute("username", username);
				 session.setAttribute("password", password);
				 session.setAttribute("mobno", mobno);
				 session.setAttribute("avlAmount",Integer.toString(avlAmount) );
				 
				 System.out.println(name+username+password+mobno);
					
				nextJsp="/withdraw.jsp";
					
				}
			} catch (UserException e) {
				nextJsp="/error.jsp";
				request.setAttribute("msg", "can not reg.");
			}
			
			
		}
			break;
		case "/withdraw.do":{
		String amountstr=	request.getParameter("amount");
		int amount=Integer.parseInt(amountstr);
		 HttpSession session=request.getSession(false);
		 
		  avlAmount=Integer.parseInt( (String) session.getAttribute("avlAmount"))	 ;
	
		 if(avlAmount>=amount)
		 {
			session.setAttribute("avlAmount", avlAmount-amount);
			nextJsp="/Success.jsp";
		 }
			
		 else{
				nextJsp="/error.jsp";
			request.setAttribute("msg", "not enough balance");
		 }
			
		}
			break;
			
			
		case "/logout.do":{
			 HttpSession session=request.getSession(false);
			 session.invalidate();
			 nextJsp="/index.jsp";
		}
break;
		}
	
	RequestDispatcher dispatcher=request.getRequestDispatcher(nextJsp);
	dispatcher.forward(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);

	}
}
